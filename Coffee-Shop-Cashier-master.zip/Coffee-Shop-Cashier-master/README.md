# Coffee-Shop-Cashier
A simple Java cashier program (with touch-screen GUI) that I developed a long time ago

### Screenshot
![screenshot](/screenshot.png)

### Functionality
1. Add Order and display the prices in the screen on the right
2. Delete previous item
3. Subtotal = total + tax
4. If member get discount

Not sure if your shop will be exactly like this but maybe you can use this repo and modify it according to your shop

### COPYRIGHT
JUST KIDDING NO COPYRIGHT FOR THIS. PLS USE IT AND STAR THE REPO
